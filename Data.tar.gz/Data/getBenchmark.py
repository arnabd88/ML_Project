
import sys
import re
import copy
import math
import os


if('-fDir' in sys.argv):
	fdir = sys.argv[sys.argv.index('-fDir')+1]
else:
	print "Provide the absolute from dir"
	exit(-1)

if('-oDir' in sys.argv):
	odir = sys.argv[sys.argv.index('-oDir')+1]
else:
	print "Provide the absolute out dir"

currDir = os.getcwd()

print "Going to "+ fdir + "..........................."
os.chdir(fdir)
dirList = [x[0] for x in os.walk(fdir)]

fileDict = dict([])

for dir in dirList:
	dirName = dir.split("/")[-1]
	#fileDict[dirName] =  [f.split(".")[0] for f in os.listdir(dir) if os.path.isfile(os.path.join(dir,f))]
	fileDict[dirName] = []
	for f in os.listdir(dir):
		name = ".".join(f.split(".")[:-1])
		if( (f.split(".")[-1]=='c' or f.split(".")[-1]=="i") and os.path.isfile(os.path.join(dir,f)) and name not in fileDict[dirName]):
			fileDict[dirName].append(name)

os.chdir(odir)
fout = open("BenchmarkList",'w')

for i,v in fileDict.iteritems():
	s = str(i)+":"+str(v)+"\n"
	fout.write(s)




os.chdir(currDir)



